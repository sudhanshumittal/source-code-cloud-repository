#include <iostream>
using namespace std;
main(){
	cout<<"hello world";
	int a = 2;
}