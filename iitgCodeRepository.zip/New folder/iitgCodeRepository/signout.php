<?php 
include './config.php';
include './include.php';
destroy_session();
?>
